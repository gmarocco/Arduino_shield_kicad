const int EspOutput = 5;    // ESP8266 output
const int rele = 4;      // the number of the LED pin
const int led= 13;
void setup() {
  pinMode(EspOutput, INPUT);
  pinMode(rele, OUTPUT);
  pinMode(led, OUTPUT);
  // put your setup code here, to run once:

}

void loop() {
  if (digitalRead(EspOutput))
  {
    delay(500);
   if (digitalRead(EspOutput))
   {
     digitalWrite(rele,HIGH);  
     digitalWrite(led,HIGH);
   }
   else 
  {
    digitalWrite(led,LOW); 
    digitalWrite(rele,LOW);   
  }
    
  }
 
}
