#define RELE 4
#define SWITCH1 7
#define SWITCH2 9
int val=0;


int rossoPin = 8;
int verdePin = 12;
int bluPin = 13;
int val1=0;
int val2=0;

void setup(){
  pinMode(rossoPin, OUTPUT);
  pinMode(verdePin, OUTPUT);
  pinMode(bluPin, OUTPUT);
  pinMode(RELE, OUTPUT);
  pinMode(SWITCH1, INPUT);
  pinMode(SWITCH2, INPUT);
  
}

void loop(){
  val1=digitalRead(SWITCH1);
  val2=digitalRead(SWITCH2);
  digitalWrite(RELE,val1);
   rgb(255, 0, 0);
  delay(1000);
  rgb(255, 255, 0);
  delay(1000);
  rgb(0, 255, 0);
  delay(1000);
  rgb(0, 255, 255);
  delay(1000);
  rgb(0, 0, 255);
  delay(1000);
  rgb(255, 0, 255);
  delay(1000);
}

void rgb(int rosso, int verde, int blu){
  analogWrite(rossoPin, rosso);
  analogWrite(verdePin, verde);
  analogWrite(bluPin, blu);
}
