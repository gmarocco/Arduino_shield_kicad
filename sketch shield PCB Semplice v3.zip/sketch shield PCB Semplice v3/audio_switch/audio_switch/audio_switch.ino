/*int pin = 2;
unsigned long duration;

void setup() {
  Serial.begin(9600);
  pinMode(pin, INPUT);
}

void loop() {
  duration = pulseInLong(pin, HIGH);
  Serial.println(duration);
}
*/
const byte ledPin = 12;
const byte rele = 4;
const byte interruptPin = 2;
volatile byte state = LOW;
unsigned char count =0;
unsigned char ON =0;
unsigned char OFF =0;
unsigned long timeComparison = 0;
unsigned char alreadyON =0;

void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(interruptPin, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(interruptPin), checkComparator, RISING);
  Serial.begin(9600);
}

void loop() {
   Serial.println(count);
  if (ON==1 && alreadyON==0)
  {
  digitalWrite(ledPin, HIGH);
  digitalWrite(rele, HIGH);
  alreadyON=1;
  count=0;
  Serial.println("ON");
  }
  
  
  
  if (OFF==1){
   digitalWrite(ledPin, LOW); 
   digitalWrite(rele, LOW); 
   Serial.println("OFF");
   alreadyON =0;
   count=0;
   OFF=0;
  }
}

void checkComparator() {
  count++;
 switch (count){
    case 1:
    timeComparison=millis();
     break;
     case 2:
     timeComparison=(millis())-timeComparison;
      if (timeComparison <2000)
       {
        ON=1; 
        OFF=0;
        timeComparison=millis();
        }
        else{
          count=0;
           }
        break;
   case 3:
     timeComparison=(millis())-timeComparison;
      if (timeComparison <2000)
       {
        ON=0; 
        OFF=1;
        count =0;
        }
        else{
          count=0;
           }
        break;
    default:
    count=0;
    break;
 }
   }
   
