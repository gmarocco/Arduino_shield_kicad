/*
  DigitalReadSerial

  Reads a digital input on pin 2, prints the result to the Serial Monitor

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/DigitalReadSerial
*/

// digital pin 2 has a pushbutton attached to it. Give it a name:
int pushButton1 = 7;
int pushButton2 = 9;
int LED_blue =13;
int LED_green =12;

// the setup routine runs once when you press reset:
void setup() {
  // initialize serial communication at 9600 bits per second:
  Serial.begin(9600);
  // make the pushbutton's pin an input:
  pinMode(pushButton1, INPUT);
  pinMode(pushButton2, INPUT);
  pinMode(LED_blue, OUTPUT);
  pinMode(LED_green, OUTPUT);
  
}

// the loop routine runs over and over again forever:
void loop() {
  // read the input pin:
 int buttonState1 = digitalRead(pushButton1);
  int buttonState2 = digitalRead(pushButton2);
  // print out the state of the button:
  //Serial.println(buttonState1);
  Serial.println(buttonState2);
 if(buttonState1==1)
  {
    digitalWrite(LED_green, HIGH);
  }
  else digitalWrite(LED_green, LOW);
  
  if(buttonState2==1)
  {
    digitalWrite(LED_blue, HIGH);
  }
   else digitalWrite(LED_blue, LOW);
  
  delay(1);        // delay in between reads for stability
}
